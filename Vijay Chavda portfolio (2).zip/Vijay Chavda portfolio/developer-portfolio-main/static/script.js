var typed = new Typed(".text", {
    strings: ["Python Developer . . ." , "RPA Developer . . ." , "Web Developer . . ."],
    typeSpeed: 70,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})